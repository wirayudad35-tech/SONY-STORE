# Roblox Followers Panel

Cara menjalankan:

1. Install Node.js
2. Buat project Vite React
3. Ganti file App.jsx dengan file ini
4. Jalankan:
npm install
npm run dev
