export default function RobloxFollowersPanel() {
  const packages = [
    { followers: '1.000 Followers', price: 'Rp24.000' },
    { followers: '5.000 Followers', price: 'Rp120.000' },
    { followers: '10.000 Followers', price: 'Rp240.000' },
    { followers: '50.000 Followers', price: 'Rp1.200.000' },
    { followers: '100.000 Followers', price: 'Rp2.400.000' },
  ];

  const checkout = () => {
    const username = document.getElementById('username').value;
    const paket = document.getElementById('paket').value;
    const pembayaran = document.getElementById('pembayaran').value;

    if (!username || !paket || !pembayaran) {
      alert('Lengkapi semua data terlebih dahulu');
      return;
    }

    const orderBaru = {
      id: Date.now(),
      username,
      paket,
      pembayaran,
      status: 'Menunggu Pembayaran',
      tanggal: new Date().toLocaleString(),
    };

    const orders = JSON.parse(localStorage.getItem('orders') || '[]');
    orders.push(orderBaru);
    localStorage.setItem('orders', JSON.stringify(orders));

    const pesan = `Halo Admin,%0A%0ASaya ingin order followers Roblox.%0A%0AUsername : ${username}%0APaket : ${paket}%0APembayaran : ${pembayaran}`;

    alert('Order berhasil disimpan');

    window.open(`https://wa.me/6281234567890?text=${pesan}`, '_blank');
  };

  const orders =
    typeof window !== 'undefined'
      ? JSON.parse(localStorage.getItem('orders') || '[]')
      : [];

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-5xl font-bold text-green-400 text-center mb-10">
          PANEL JASA SUNTIK FOLLOWERS ROBLOX
        </h1>

        <div className="grid md:grid-cols-3 gap-6 mb-10">
          {packages.map((item, index) => (
            <div key={index} className="bg-zinc-900 border border-green-500 rounded-3xl p-6">
              <h2 className="text-2xl font-bold text-green-400 mb-3">{item.followers}</h2>
              <p className="text-3xl font-bold mb-4">{item.price}</p>
            </div>
          ))}
        </div>

        <div className="bg-zinc-900 rounded-3xl p-8 border border-green-500 mb-10">
          <h2 className="text-3xl font-bold text-green-400 mb-6">Form Pemesanan</h2>

          <div className="grid gap-4">
            <input
              id="username"
              type="text"
              placeholder="Username Roblox"
              className="bg-black border border-gray-700 rounded-xl p-4"
            />

            <select id="paket" className="bg-black border border-gray-700 rounded-xl p-4">
              <option value="">Pilih Paket Followers</option>
              <option>1.000 Followers - Rp24.000</option>
              <option>5.000 Followers - Rp120.000</option>
              <option>10.000 Followers - Rp240.000</option>
              <option>50.000 Followers - Rp1.200.000</option>
              <option>100.000 Followers - Rp2.400.000</option>
            </select>

            <select id="pembayaran" className="bg-black border border-gray-700 rounded-xl p-4">
              <option value="">Metode Pembayaran</option>
              <option>QRIS</option>
              <option>DANA</option>
              <option>GOPAY</option>
              <option>Transfer Bank</option>
            </select>

            <button
              onClick={checkout}
              className="bg-green-500 hover:bg-green-600 text-black font-bold py-4 rounded-2xl"
            >
              Checkout Otomatis
            </button>
          </div>
        </div>

        <div className="bg-zinc-900 rounded-3xl p-8 border border-green-500">
          <h2 className="text-3xl font-bold text-green-400 mb-6">Status Proses Order</h2>

          <table className="w-full">
            <thead>
              <tr>
                <th>Username</th>
                <th>Paket</th>
                <th>Pembayaran</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.id}>
                  <td>{order.username}</td>
                  <td>{order.paket}</td>
                  <td>{order.pembayaran}</td>
                  <td>{order.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
